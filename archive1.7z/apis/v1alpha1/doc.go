/*
Copyright 2021 Upbound Inc.
*/

// Package v1alpha1 contains the core resources of the postgresql jet provider.
// +kubebuilder:object:generate=true
// +groupName=postgresql.crossplane.io
// +versionName=v1alpha1
package v1alpha1
