/*
Copyright 2022 Upbound Inc.
*/

// Package v1beta1 contains the core resources of the postgresql upjet provider.
// +kubebuilder:object:generate=true
// +groupName=postgresql.crossplane.io
// +versionName=v1beta1
package v1beta1
